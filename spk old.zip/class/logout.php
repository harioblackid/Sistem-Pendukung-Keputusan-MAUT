<?php
session_start();
include 'Core.inc.php';
$core = new Core();

echo $core->ajaxRedirect("$base_url");
session_destroy();
?>