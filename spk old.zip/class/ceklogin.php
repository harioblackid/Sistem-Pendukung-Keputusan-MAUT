<?php
include 'Core.inc.php';

include 'Config.php';
include 'User.inc.php';
    

$config = new Config();
$db = $config->getConnection();

$login = new User($db);
    
    $login->username = $_POST['username'];
    $login->password = md5($_POST['password']);
    
    if($login->login()) {
    	echo $login->ajaxRedirect("$base_url");
    }
    else
    {
    	echo $login->errorMessage("Username / Password tidak benar");
    }

?>