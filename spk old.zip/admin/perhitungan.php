<?php if($action == null) : ?>
<section class="content-header">
    <h1>
        <?=$title; ?>
    	<small><?=$key; ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href='<?= $base_url; ?>'><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href='<?= "$base_url/$page"; ?>'> <?=$title; ?></a></li>
        <li class="active"><?=$key; ?></li>
    </ol>
</section>

<!-- Main content -->
<section class="content">
	<div class='box box-default'>
		<div class='box-header with-border'>
			<h3 class="box-title">A1 - Pantai Samudra Baru</h3>
	 	</div>
	 	<div class='box-body'>
	 		<table id="simpletable" class='table table-bordered table-responsive'>
	 			<thead>
	 				<tr>
	 					<td>No</td>
	 					<td>Responden</td>
	 					
	 					<!-- Data Kriteria -->
	 					<td>C1</td>
	 					<td>C2</td>
	 					<td>C3</td>
	 					<td>C4</td>
	 					<td>C5</td>
	 					<td>C6</td>
	 				</tr>
	 			</thead>
	 			<tbody>
	 			<?php 
	 				// $no=1; 
	 				// $show = $kriteria->selectAll();
	 				// while ($row = $show->fetch_object()) :
	    		?>
	    			<tr>
	    				<td>No</td>
	 					<td>Responden</td>
	 					
	 					<!-- Data Kriteria -->
	 					<td>C1</td>
	 					<td>C2</td>
	 					<td>C3</td>
	 					<td>C4</td>
	 					<td>C5</td>
	 					<td>C6</td>
	      			</tr>
	      			<?php 
	      		// 	$no++; 
	      		// endwhile ; 
	    
	      	?>
	   			</tbody>	
	   		</table>
	   	</div>
	   	<div class='box-footer'>

	   	</div>
	</div>

</section>

<?php endif; ?>