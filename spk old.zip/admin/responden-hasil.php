<?php if($action == null) : ?>
<section class="content-header">
    <h1>
        <?=$title; ?>
    	<small><?=$key; ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href='<?= $base_url; ?>'><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href='<?= "$base_url/$page"; ?>'> <?=$title; ?></a></li>
        <li class="active"><?=$key; ?></li>
    </ol>
</section>

<section class="content">
	<div class="row">
		<!-- Detail Kriteria -->
		<div class="col-md-4">
			<div class="box box-primary">
				<form id="form" method="post" action='<?= "$base_url/admin/normalisasi-hitung.php"; ?>'>
				<div class="box-header with-border">
					<h3 class="box-title">Bobot Preferensi</h3>
				</div>
				<div class="box-body">
					<div class="alert alert-warning" style="display: none;" id="cek">
		                <i class="fa fa-refresh fa-spin"></i> Memproses ...
		            </div>
		            <div id="infoMessage"></div>

					<table class='table table-bordered table-responsive'>
						<thead>
							<tr>
								<td>Kode</td>
								<td>Nama</td>
								<td>Bobot</td>
							</tr>
						</thead>

						<tbody>
						<?php
							$result = $kriteria->selectAll();
							while($row = $result->fetch_object()) :	
						?>
							<tr>
								<td><?= $row->id_kriteria; ?></td>
								<td><?= $row->nama_kriteria; ?></td>
								<td><?= $row->bobot_preferensi; ?></td>
							</tr>
						<?php endwhile; ?>
						</tbody>
					</table>
				</div>
				<div class="box-footer">
					<button class="btn btn-primary btn-block"><i class="fa fa-recycle"></i> Proses </button>
				</div>
			</div>
		</div>

		<!-- Reapet Alternatif -->
		
		<div class="col-md-8">
		<?php
			$show_alternatif = $hitung->getAlternatif();
			while($row_alt = $show_alternatif->fetch_object()) :
		?>
		<div class='box box-default'>
			<div class='box-header with-border'>
				<h3 class="box-title"><?= $row_alt->id_alternatif; ?> - <?= $row_alt->nama; ?></h3>
		 	</div>
		 	<div class='box-body'>
		 		<table class='table table-hovered table-responsive table-striped'>
		 			<thead>
		 				<tr>
		 					<td>No</td>
		 					<td>Responden</td>
		 					
		 					<!-- Data Kriteria -->
		 					<?php 
		 					$show_kriteria = $hitung->getKriteria();
		 					while($row = $show_kriteria->fetch_object()) :
		 					?>
		 					
		 					<td align="center">
		 						<strong><small><?= $row->nama_kriteria; ?></small></strong> <br>
		 						<?= $row->id_kriteria; ?>
		 					</td>
		 					
		 					<?php endwhile; ?>
		 				</tr>
		 			</thead>
		 			<tbody>
			 			<?php 
			 				
			 				$show_res = $hitung->getResponden();
			 				while ($row_res = $show_res->fetch_object()) :
			    		?>
		    			<tr>
		    				<td><?= $row_res->id; ?></td>
		 					<td><?= $row_res->nama_lengkap; ?></td>
		 					
		 					<!-- Data Kriteria -->

		 					<?php 
		 					$result1 = $hitung->getKriteria();
		 					while ($row_krt = $result1->fetch_object()) :
		 					?>

		 					<td align="center">
		 						<?php 
		 							$exec = $hitung->getCell($row_res->id, $row_alt->id_alternatif, $row_krt->id_kriteria);
		 							$cell = $exec->fetch_object();

		 							echo $cell->nilai;		
		 						?>
		 					</td>
							<?php endwhile; //End Cell ?>
		      			</tr>
		      			<?php 

		      			// End Responden
		      			endwhile ; 
		      			?>
		   			</tbody>
		   			<tfoot>
		   				<tr>
		   					<td colspan="2">Rata-rata</td>
		   					
		   					<?php
		   					$result2 = $hitung->getKriteria();
		   					while ($row_krt = $result2->fetch_object()){

		   						//Ambil Nilai rata-rata dari setiap kriteria 
		   						$resultl2 = $hitung->kriteriaAVG($row_alt->id_alternatif, $row_krt->id_kriteria);
		   						$row_avg = $resultl2->fetch_object();

		   						echo "<td align='center'><strong>". round($row_avg->nilai, 3) . "</strong></td>";

		   					}
		   					?>
		   				</tr>
		   			</tfoot>	
		   		</table>
		   	</div>
		</div>	
		<?php endwhile; ?>
		<!-- End Repeat -->
	</div>
	
	
	</div>

<!-- Main content -->
</section>

<?php endif; ?>